public class Multiplo
{
    public static void main(String[] args)
    {
        for (int i = 42; i < 150; i++)
        {
            if (i % 4 == 0) {
                System.out.println(i);
            }
        }
    }
}
